import json
import boto3
import re
import requests
from requests_aws4auth import AWS4Auth
import inspect
import os
from elasticsearch import Elasticsearch,RequestsHttpConnection,helpers
from elasticsearch.helpers import bulk
import logging
import sys
import urllib
import datetime


logger = logging.getLogger()
logger.setLevel(logging.INFO)

def set_mapping(es, index_name = "content_engine", doc_type_name = "en"):
    mapping = {
    "settings": {
        "number_of_shards": 2,
        "number_of_replicas": 1
    },
    "mappings": {
        "properties": {
            "some_string": {
                "type": "text" # formerly "string"
            },
            "some_bool": {
                "type": "boolean"
            },
            "some_int": {
                "type": "integer"
            },
            "some_more_text": {
                "type": "text"
            }
        }
    }
}
    response = es.indices.create(
    index="content",
    body=mapping,
    ignore=400 # ignore 400 already exists code
     )
     
    if 'acknowledged' in response:
      if response['acknowledged'] == True:
        print ("INDEX MAPPING SUCCESS FOR INDEX:", response['index'])

# catch API error response
    elif 'error' in response:
      print ("ERROR:", response['error']['root_cause'])
      print ("TYPE:", response['error']['type'])

# print out the response:
    print ('\nresponse:', response)
    
    my_mapping = {
            "properties": {
                "a": {
                    "type": "text"
                 },
                 "b": {
                    "type": "text"
                 }
            }
        }
    response = es.indices.create(index="content2" ,ignore=400)
    mapping_index = es.indices.put_mapping(index = "content2",body = my_mapping)
    print("put mapping o/p={}".format(mapping_index))
    
def get_index_name(alias_name,elastic):
    index_nm=alias_name
    counter=0
    base_index=index_nm+"_"+str(counter)
    while (elastic.indices.exists(index=base_index)):
            if counter >= 10:
             sys.exit("Number of Index for alias {} is already 10 , clean up required !!".format(alias_name))
            else:
             print("Positive number")
             base_index=index_nm+"_"+str(counter)
             counter=counter+1
    return base_index    

def get_alias_name(file_name,path):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=path, Key=file_name)
    body = obj['Body'].read().decode('utf-8') 
    lines = body.splitlines()
    return lines[0]
        
def warm_index(es,indexname,indextype,id=1):
    #response=es.get(index=indexname, doc_type=indextype, id=id)
    es.indices.refresh(indexname)
    response=es.cat.count(indexname, params={"format": "json"})
    return response
    

def get_parameters(awsregion):
    
    ssm = boto3.client('ssm', awsregion)
    response = ssm.get_parameters(Names=['Elasticsearch-us-east'])
    for parameter in response['Parameters']:
        return parameter['Value']


def get_data_from_file(file_name,path):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=path, Key=file_name)
    body = obj['Body'].read().decode('utf-8') 
    lines = body.splitlines()
    return lines

'''
generator to push bulk data from a JSON
file into an Elasticsearch index
'''
def bulk_json_data(json_file, _index, doc_type,path):
    json_list = get_data_from_file(json_file,path)
    count=0
    for doc in json_list[1:]:
        #print("inside function :{} ".format(inspect.currentframe().f_code.co_name))
    # use a `yield` generator so that the data
    # isn't loaded into memory
        if '"index"' not in doc:
            yield {
                "_index": _index,
                "_op_type": 'index',
                "_type": doc_type,
                #"_id": count,
                "_source": doc
            }
            count+=1


def bulk_load(file_name,index_name,doc_type,elastic,path):
    try:
        # make the bulk call, and get a response
        print("inside function :{} ".format(inspect.currentframe().f_code.co_name))
        #print(bulk_json_data(file_name, index_name, doc_type,path).next())
        response = helpers.bulk(elastic, bulk_json_data(file_name, index_name, doc_type,path))
    except Exception as e:
        print("ERROR:", e)
    else:
        return response
    finally:
        pass


def get_es_client(elastic_search_end_point,region,service):
    session = boto3.Session()
    credentials = session.get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    elastic = Elasticsearch(elastic_search_end_point, http_auth=awsauth, port=443,use_ssl=True, connection_class=RequestsHttpConnection)
    return elastic

def publish_success(region,index):
    # Create an SNS client
    sns = boto3.client('sns')
    jobregion=region
    indexer=index
    today=datetime.datetime.now()
    successtime='{:%Y-%b-%d %H:%M:%S}'.format(today)
    message1= "Indexer Job :" + indexer + "\n" + "succedded at region " + jobregion + " at  " + successtime
    # Publish a simple message to the specified SNS topic
    try:
       response = sns.publish(TopicArn='arn:aws:sns:us-east-1:xxxxxxxxxxxx:Notify-es', Message=message1, )  
    except Exception as e:
        print("ERROR:", e)
    else:
        return response
    finally:
        pass

def main(event, context):
    #region = 'us-east-1'
    region = os.environ.get('AWS_REGION')
    index_config=os.environ.get('config')
    print("Config is {}".format(index_config))
    indexconfig_dct=eval(index_config)
    index_loc=indexconfig_dct[region][0]
    elastic_search_end_point=indexconfig_dct[region][1]
    logger.info(region)
    service = 'es'

    
    elastic = get_es_client(elastic_search_end_point,region,service)
    for record in event['Records']:
      ### Parse the Input messege to get S3 Bucket name and S3 Filename ###  
      message = record['body']
      
      parsed_message = json.loads(message)
      parsed_message2 = json.loads(parsed_message['Message'])
      s3bucket = parsed_message2['Records'][0]['s3']['bucket']['name']
      S3filename = parsed_message2['Records'][0]['s3']['object']['key']
      print("file name is :{}".format(S3filename))
      
      ### Retreive the Alias Name and create the Indices Name ###
      
      alias_name = get_alias_name(S3filename,s3bucket)
      index_name=get_index_name(alias_name,elastic)
      print("index name is :{} Alias Name is :{}".format(index_name,alias_name))
      
      doc_type = 'accountinfo'
      
      try:
         set_mapping(elastic)
         response=bulk_load (S3filename ,index_name ,doc_type,elastic,s3bucket)
         print("total record loaded are :{}".format(response[0]))
      except Exception as e:
          print("Load to elasticsearch failed with exception:{}".format(e))
      else:
         # publish_success(index_loc,index_name)
          warmed=warm_index(elastic,index_name,doc_type)
          print(" Warmed up index : {} , value is {}".format(index_name,warmed))
      
      
      
      
      

